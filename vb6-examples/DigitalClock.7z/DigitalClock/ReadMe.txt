Digits - VB5 PicClip demo program
Copyright (c) 1994-97 SoftCircuits Programming (R)
Redistributed by Permission.

This VB5 demo shows how you can create a digital display that appears
like some sort of electronic LCD/LED display and includes several
bitmaps that can be used to create such displays. You will need the
PicClip control that ships with the professional edition of Visual
Basic in order to run the demo program.

Note: At the time this demo was put together, SoftCircuits was
putting together an enhanced version of this code called LCD, which
is implemented as a control that is much easier to use and doesn't
require the PicClip control. At this time, this enhanced version will
not be distributed for free. If you find this code useful but it
doesn't do exactly what you want, you might want to drop by our web
site to see what else we have available.

This program may be distributed on the condition that it is
distributed in full and unchanged, and that no fee is charged for
such distribution with the exception of reasonable shipping and media
charged. In addition, the code in this program may be incorporated
into your own programs and the resulting programs may be distributed
without payment of royalties.

This example program was provided by:
 SoftCircuits Programming
 http://www.softcircuits.com
 P.O. Box 16262
 Irvine, CA 92623
